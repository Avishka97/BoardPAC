[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![npm version](https://badge.fury.io/js/primeicons.svg)](https://badge.fury.io/js/primeicons)
[![Join the chat at https://gitter.im/primefaces/primeicons](https://badges.gitter.im/primefaces/primeicons.svg)](https://gitter.im/primefaces/primeicons?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

---

![PrimeIcons Logo](https://www.primefaces.org/wp-content/uploads/2018/07/primeicons-logo.svg "PrimeIcons")

Font Icon Library for Prime UI Libraries: [PrimeNG](https://www.primefaces.org/primeng/#/icons/) | [PrimeReact](https://www.primefaces.org/primereact/#/icons/) | [PrimeFaces](https://primefaces.org/showcase/ui/misc/primeicons.xhtml) | [PrimeVue](https://primefaces.org/primevue/#/icons) 

---

![Icons Preview](https://www.primefaces.org/wp-content/uploads/2019/07/primeicons-180.png "PrimeIcons")
